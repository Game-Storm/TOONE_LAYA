require("weapp-adapter.js");
require("libs/laya.wxmini.js");
window.loadLib = require;
require("index.js")